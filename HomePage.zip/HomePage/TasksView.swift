//
//  TasksView.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//

import SwiftUI

struct TasksView : View {
    @State private var selectedSegment = 0
    let segments = ["Food", "Supplement", "Vaccination"]
    var body: some View {
        
        ZStack{
            
            Image("Background")
                .resizable()
                .scaledToFill().edgesIgnoringSafeArea(.all)
            
            ZStack{
                if selectedSegment == 0 {
                    ZStack{
                        HStack{
                            Text("!")
                                .font(.custom("Chalkduster", size: 80))
                                .foregroundColor(Color("LightOrange"))
                                .frame(width: 80, height: 80)
                                .padding(.leading, -120)
                                .padding(.top, 650)
                            
                            
                            
                            Text("Cats need meat — you shouldn't \n feed them a vegetarian diet." ).font(.system(size:16))
                                .foregroundColor(.brown1)
                                .padding()
                                .background(Color.light).cornerRadius(10).offset(x: -60 , y: 330)
                        }.padding(.bottom,70)
                    }
                    VStack{
                        Rectangle().fill(Color.brown2).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x :0 , y: -180)
                        
                        Rectangle().fill(Color.midbrown).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x: 0 , y: -160)
                        
                        Rectangle().fill(Color.midbrown).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x :0 , y: -140)
                        
                        ZStack{
                            
                            
                            Text("Meal one").padding(.trailing,120).padding(.top , -327).fontWeight(.bold).foregroundColor(.light).font(.title2)
                            
                            Text("Meal two").padding(.trailing,120).padding(.top,-260).fontWeight(.bold).foregroundColor(.lightbrown1).font(.title2)
                            
                            NavigationLink {
                                CalendarView()
                            } label: {
                                Text("+")
                            }
                                
                                .padding(.trailing,120).padding(.top , -190).fontWeight(.bold).foregroundColor(.lightbrown1).font(.title)
                                
                            
                        }
                        
                        
                    }
                }
                else if selectedSegment == 1 { VStack{
                    ZStack{
                        
                        Text("Omega-3 Fatty Acids: \nThese supplements are essential \nfor your cat's skin and coat " )
                            .font(.system(size:16))
                            .foregroundColor(.brown1)
                            .padding()
                            .background(Color.light)
                            .cornerRadius(10)
                            .offset(x: -60 , y: 300)
                    }.padding(.bottom,-170)
                    
                    VStack{
                        Rectangle().fill(Color.brown2).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x :0 , y: -180)
                        Rectangle().fill(Color.midbrown).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x: 0 , y: -160)
                        Rectangle().fill(Color.midbrown).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x :0 , y: -140)
                        
                        ZStack{
                            Text("Omega fish").padding(.trailing,120).padding(.top , -327).fontWeight(.bold).foregroundColor(.light).font(.title2)
                            Text("Vitamin E").padding(.trailing,120).padding(.top,-255).fontWeight(.bold).foregroundColor(.lightbrown1).font(.title2)
                            
                            NavigationLink {
                                CalendarView()
                            } label: {
                                Text("+")
                            }.padding(.trailing,120).padding(.top , -190).fontWeight(.bold).foregroundColor(.lightbrown1).font(.title)
                            
                        }
                    }
                    
                }
                }
                else if selectedSegment == 2 { VStack{
                    ZStack{
                        Text("Getting your cat vaccinated \ncan keep them safe from a fatal disease, \nand helps protect you too!" ).font(.system(size:16)).foregroundColor(.brown1).background(Color.light).cornerRadius(10).offset(x: -60 , y: 300)
                    }.padding(.bottom,-170)
                    
                    Rectangle().fill(Color.brown2).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x :0 , y: -180)
                    Rectangle().fill(Color.midbrown).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x: 0 , y: -160)
                    Rectangle().fill(Color.midbrown).frame(width:340 ,height: 45).cornerRadius(25).padding(.trailing , 120).offset(x :0 , y: -140)
                    
                    ZStack{
                        Text("Rabies virus").padding(.trailing,120).padding(.top , -327).fontWeight(.bold).foregroundColor(.light).font(.title2)
                        Text("Feline calicivirus").padding(.trailing,120).padding(.top,-255).fontWeight(.bold).foregroundColor(.lightbrown1).font(.title2)
                        NavigationLink {
                            CalendarView()
                        } label: {
                            Text("+")
                        }.padding(.trailing,120).padding(.top , -190).fontWeight(.bold).foregroundColor(.lightbrown1).font(.title)
                        
                    }
                }
                }
            }
            VStack {
                
                Picker("Options", selection: $selectedSegment) {
                    ForEach(0..<segments.count) { index in
                        Text(self.segments[index]).tag(index)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                .frame(width: 380 , height: 500)
                .padding(.bottom , 600)
                .padding(.trailing, 120)
                .background(Color.clear)
                .cornerRadius(10)
            }
            
        }
        
    }
    
    
}


#Preview {
    TasksView()
}
