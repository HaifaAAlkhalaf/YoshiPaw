//
//  ReminderView.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//

import SwiftUI

struct ReminderView: View {
    var body: some View {
        MainView()
    }
}

struct MainView: View {
    @State private var inputText: String = "" // State variable for the text field

    var body: some View {
        ZStack {
            // Set the background image
            Image("Background")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .edgesIgnoringSafeArea(.all)

            VStack {
                // Title Text
                Text("Reminders")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(Color("BrownColor"))
                    .multilineTextAlignment(.center)
                    .padding(.top, 30.0) // Adjust padding as needed

                // Add Labels
                VStack(spacing: 27.0) {
                    
                  
                    
                    LabelView(text: "Feed me!!                            8:00 AM                                                                                                                  ")
                    LabelView(text: "Vaccination Coming Up!          9 AM")
                }
                .padding(.top, 145.0)
                .frame(width: 300, height: 80) 

                Spacer()
            }

            // Notification Bell Icon
            VStack {
                HStack {
                    Spacer()
                    Image(systemName: "bell.fill")
                        .foregroundColor(Color(red: 0.575, green: 0.666, blue: 0.392))
                        .font(.system(size: 30))
                        //.padding([.top, .trailing], 32)
                        .padding(EdgeInsets(top: 30, leading: 300, bottom: 650, trailing: 30))
                }
                Spacer()
            }
        }
    }
}

struct LabelView: View {
    var text: String

    var body: some View {
        Text(text)
            .padding()
            .background(Color.white)
            .foregroundColor(Color("BrownColor"))
            .cornerRadius(8)
            .shadow(radius: 4)
    }
}

struct ReminderView_Previews: PreviewProvider {
    static var previews: some View {
        ReminderView()
    }
}

