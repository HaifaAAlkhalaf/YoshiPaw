//
//  CalendarView.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//

import SwiftUI

struct CalendarView: View {
var body: some View {
    
    
            ZStack {
            Image("Background")
                .resizable()
                .scaledToFill().edgesIgnoringSafeArea(.all)
            
            Rectangle().fill(Color.light).frame(width:330,height: 80).cornerRadius(15).padding(.top,-260)
            
            Rectangle().fill(Color.midbrown).frame(width:45,height: 25).cornerRadius(10).padding(.top,-253).offset(x:120, y: 0 )
                
                
                ZStack{
                    Button("Add"){
                        /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                    }.foregroundColor(.brown1).font(.caption).padding(.top,-250).padding(.leading,240)
                    
                    
                }
                VStack {
                           HStack {
                               Rectangle()
                                   .fill(Color.darkOrange)
                                   .frame(width: 10, height: 30)
                                   .cornerRadius(10)
                                   .padding(.top, -160)
                                   .offset(x: 1, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -160)
                                   .offset(x: -10, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -160)
                                   .offset(x: -10, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -160)
                                   .offset(x: -10, y: 0) // Moved to the left
                           }

                           HStack {
                               Rectangle()
                                   .fill(Color.green1)
                                   .frame(width: 10, height: 30)
                                   .cornerRadius(10)
                                   .padding(.top, -110)
                                   .offset(x: 1, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -110)
                                   .offset(x: -10, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -110)
                                   .offset(x: -10, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -110)
                                   .offset(x: -10, y: 0) // Moved to the left
                           }
                           
                   
                           HStack {
                               Rectangle()
                                   .fill(Color.green1)
                                   .frame(width: 10, height: 30)
                                   .cornerRadius(10)
                                   .padding(.top, -60)
                                   .offset(x: 1, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -60)
                                   .offset(x: -10, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -60)
                                   .offset(x: -10, y: 0) // Moved to the left
                               
                               Rectangle()
                                   .fill(Color("midbrown"))
                                   .frame(width: 100, height: 30)
                                   .cornerRadius(5)
                                   .padding(.top, -60)
                                   .offset(x: -10, y: 0) // Moved to the left
                           }

                }
            HStack{
                Rectangle().fill(Color.midbrown).frame(width:80,height: 25).cornerRadius(5).padding(.top,-215).offset(x:70, y: 0 )
                Rectangle().fill(Color.midbrown).frame(width:80,height: 25).cornerRadius(5).padding(.top,-215).offset(x:70, y: 0 )
            }
            Divider().frame(width: 280 ).offset(x: 20 , y: -220)
            
            VStack{
                Text("Calender").fontWeight(.semibold).font(.system(size: 32)).foregroundColor(.brown1).padding(.top,-350)
                Text("Title").fontWeight(.semibold).font(.system(size: 12)).foregroundColor(.lightbrown1).offset(x: -130, y:-230 )
                Text("Date and time").fontWeight(.semibold).font(.system(size: 12)).foregroundColor(.lightbrown1).offset(x: -102, y:-205 )
            }
              
                ZStack{
                    Text("24 June 2024").foregroundColor(.brown1).font(.system(size: 10)).offset(x: 25 , y: -203 )
                    Text("8:00 PM").foregroundColor(.brown1).font(.system(size: 10)).offset(x: 113 , y: -203 )
                    HStack{
                        Text("24 June 2024").foregroundColor(.brown1).font(.system(size: 10)).offset(x: -59 , y: -154 )
                        Text("8:00 PM").foregroundColor(.brown1).font(.system(size: 10)).offset(x: -11 , y: -154 )
                        Text("Meal one").foregroundColor(.brown1).fontWeight(.semibold).font(.system(size: 10)).offset(x: 40 , y: -154 ) }
                    
                    HStack{
                        Text("20 July 2024 ").foregroundColor(.brown1).font(.system(size: 10)).offset(x: -59 , y: -96 )
                        Text("12:00 PM").foregroundColor(.brown1).font(.system(size: 10)).offset(x: -20 , y: -96 )
                        Text("Vaccine").foregroundColor(.brown1).fontWeight(.semibold).font(.system(size: 10)).offset(x: 30 , y: -96 ) }
                    HStack{
                        Text("29 August 2024 ").foregroundColor(.brown1).font(.system(size: 10)).offset(x: -59 , y: -38 )
                        Text("7:00 PM").foregroundColor(.brown1).font(.system(size: 10)).offset(x: -20 , y: -38 )
                        Text("Vitamin E").foregroundColor(.brown1).fontWeight(.semibold).font(.system(size: 10)).offset(x: 33 , y: -38 )
                    }
                }
        }
    
    }
}

#Preview {
    CalendarView()
}
