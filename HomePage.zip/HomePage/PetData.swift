//
//  PetData.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//

import SwiftUI

class PetData: ObservableObject {
    @Published var petName: String = ""
    @Published var breed: String = ""
    @Published var age: Int = 0
    @Published var gender: String = ""
    @Published var weight: Int = 0
    @Published var moodImage: String = "HappyCat" // Default mood image
}
