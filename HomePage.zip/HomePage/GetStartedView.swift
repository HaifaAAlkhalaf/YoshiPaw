//
//  GetStartedView.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//

import SwiftUI

struct GetStartedView: View {
    @State private var rotationAngle: Double = 0
    
    var body: some View {
        NavigationView {
            ZStack {
                Image("wallpaper")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    NavigationLink(destination: AddPetView()) {
                        Text("Let's Get ")
                            .font(.custom("BigCaslon", size: 50))
                            .fontWeight(.heavy)
                            .foregroundColor(Color(red: 0.4, green: 0.269, blue: 0.302))
                            .padding(10)
                            .multilineTextAlignment(.center)
                            .cornerRadius(10)
                            .padding(.top, 50)
                    }
                    
                    NavigationLink(destination: AddPetView()) {
                        Text("STARTED")
                            .font(.custom("Chalkduster", size: 60))
                            .foregroundColor(Color(red: 0.507, green: 0.619, blue: 0.33))
                            .padding(0)
                            .rotationEffect(Angle(degrees: -10))
                    }
                    
                    Spacer() // Push the rest of the content down
                    
                    HStack {
                        Spacer() // Push the cat.hand to the right
                        VStack {
                            Spacer() // Adjust the vertical position if needed
                            NavigationLink(destination: AddPetView()) {
                                Image("cat.hand")
                                    .resizable()
                                    .frame(width: 450, height: 500)
                                    .offset(x: 0, y: 1)
                            }
                        }
                    }
                }
            }
            .navigationBarHidden(true) // Hide the navigation bar
        }
    }
}


struct GetStartedView_Previews: PreviewProvider {
    static var previews: some View {
        GetStartedView()
    }
}
