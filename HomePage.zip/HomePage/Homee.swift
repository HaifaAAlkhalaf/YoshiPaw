//
//  Homee.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//
import SwiftUI

struct Homee: View {
    @Binding var petName: String 
    @State var selectedImg = "CatTie"
    
    var body: some View {
      //  NavigationView {
            ZStack {
                Image("Background")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                
                HStack{
                    NavigationLink(destination: ReminderView()) {
                        Image(systemName: "bell.fill")
                            .foregroundColor(Color("BrownColor"))
                            .font(.system(size: 30))
                            .padding(EdgeInsets(top: 0, leading: 300, bottom: 650, trailing: 0))
                            //.padding(.trailing, 20)
                    }
                }
                
                VStack{
                   
                    VStack(alignment: .center) {
                        Image("\(selectedImg)")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 350, height: 350)
                            .padding(.top)
                        
                        Text("How does")
                            .font(.system(size: 20))
                            .foregroundColor(Color("BrownColor"))
                            .bold()
                        
                        Text("\(petName)")
                            .font(.custom("Chalkduster", size: 56))
                            .foregroundColor(Color("DarkOrange"))
                        
                        Text("feel today?")
                            .font(.system(size: 20))
                            .foregroundColor(Color("BrownColor"))
                            .bold()
                    }
                    .padding(.top, 50)
                    .padding(.trailing, 10)
                    
                    HStack(spacing: 20) {
                        Button { selectedImg = "MadCat" } label: {
                            Image("AngryMood")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80, height: 80)
                        }
                        Button { selectedImg = "HappyCat" } label: {
                            Image("HappyMood")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80, height: 80)
                        }
                        Button { selectedImg = "SadCat" } label: {
                            Image("SadMood")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80, height: 80)
                        }
                        Button { selectedImg = "SickCat" } label: {
                            Image("SickMood")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80, height: 80)
                        }
                    }
                    .padding(.trailing,50)
                    .padding(.top, 20)
                    
                    HStack {
                        Text("!")
                            .font(.custom("Chalkduster", size: 80))
                            .foregroundColor(Color("LightOrange"))
                            .frame(width: 80, height: 80)
                            .padding(.leading, -40)
                        
                        Text("Did you know that In 1963 a cat went to space!")
                            .font(.system(size: 16))
                            .foregroundColor(Color("BrownColor"))
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .padding(.trailing, 30)
                    }
                    .padding(.bottom, 90)
                    
               
                }
            }
            .navigationBarTitle("Home", displayMode: .inline)
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
      //  }
        
        .edgesIgnoringSafeArea(.bottom)
    }
}
//#Preview {
  // Homee()
//}

