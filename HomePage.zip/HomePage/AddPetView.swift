//
//  AddPetView.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//
import SwiftUI

struct AddPetView: View {
    @State var petName = ""
    @State var breed = ""
    @State var age: Int = 0
    @State var gender: String = ""
    @State var weight: Int = 0
    
    let genders = ["Male", "Female"]
    let ages = Array(0...30)
    let weights = Array(1...20)
    
    var body: some View {
     //   NavigationView {  // Add NavigationView here
            ZStack(alignment: .topLeading) {
                // Background Image
                Image("GetStarted")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                
                VStack {
                    Text("Add Pet")
                        .font(.system(size: 30))
                        .font(.headline)
                        .foregroundColor(Color("BrownColor"))
                        .padding(20)
                    
                    Image("AddPetPic")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 250, height: 250)
                        .padding(-10)
                    
                    HStack {
                        TextField("Pet's Name...", text: $petName)
                    }
                    .padding(.leading, 200)
                    .padding(.trailing, 200)
                    .textFieldStyle(OvalTextFieldStyle())
                    .padding(.bottom, -20)
                    
                    HStack {
                        VStack {
                            Text("Age")
                                .foregroundColor(.gray)
                            Picker("Age", selection: $age) {
                                ForEach(ages, id: \.self) { age in
                                    Text("\(age)").tag(age)
                                }
                            }
                            .frame(width: 90, height: 40)
                            .background(Color("TextF"))
                            .cornerRadius(90)
                        }
                        
                        VStack {
                            Text("Gender")
                                .foregroundColor(.gray)
                            Picker("Gender", selection: $gender) {
                                ForEach(genders, id: \.self) { gender in
                                    Text(gender).tag(gender)
                                }
                            }
                            .frame(width: 105, height: 40)
                            .background(Color("TextF"))
                            .cornerRadius(90)
                        }
                        
                        VStack {
                            Text("Weight")
                                .foregroundColor(.gray)
                            Picker("Weight", selection: $weight) {
                                ForEach(weights, id: \.self) { weight in
                                    Text("\(weight)").tag(weight)
                                }
                            }
                            .frame(width: 90, height: 40)
                            .background(Color("TextF"))
                            .cornerRadius(90)
                        }
                    }
                    .padding()
                    
                    HStack {
                        TextField("Pet's Breed...", text: $breed)
                    }
                    .padding(.leading, 200)
                    .padding(.trailing, 200)
                    .textFieldStyle(OvalTextFieldStyle())
                    .padding(.top, -10)
                    
                    NavigationLink{
                        
                        ContentView(petName: $petName , age: $age, gender: $gender, breed: $breed, weight: $weight)
                    }label: {
                          // Add NavigationLink here
                        Text("Create account")
                            .foregroundColor(Color.white)
                            .frame(width: 300, height: 40)
                            .background(Color(red: 0.575, green: 0.666, blue: 0.392))
                            .cornerRadius(20)
                            .padding(.leading, 200)
                            .padding(.trailing, 200)
                            .padding(.bottom, -20)
                            .textFieldStyle(OvalTextFieldStyle())
                    }
                }
            }
       // }
            .navigationBarBackButtonHidden(true)
    }
}

struct OvalTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(10)
            .background(Color("TextF"))
            .cornerRadius(50)
            .padding()
    }
}

struct AddPetView_Previews: PreviewProvider {
    static var previews: some View {
        AddPetView()
    }
}

