//
//  ProfileView.swift
//  HomePage
//
//  Created by Sara Altamimi on 07/02/1446 AH.
//

import SwiftUI

struct ProfileView: View {
    
    
        @Binding var petName: String
        @Binding var age: Int
        @Binding var gender: String
        @Binding var breed: String
        @Binding var weight: Int
        
    var body: some View {
        ZStack{
            
            Image("Background")
                .resizable()
                .ignoresSafeArea()
            
          
            
            VStack (alignment: .center, spacing:1) {
                
                
                
                Text("Profile")
                //.offset(x:50,y:-60)
                    .padding(.top)
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundColor(Color(red: 0.4, green: 0.269, blue: 0.302))
                
                
                
                Text("\(petName)")
                //.offset(x:0,y:-45)
                    .font(.custom("Chalkduster", size: 61))
                    .fontWeight(.heavy)
                    .foregroundColor(Color(red: 0.923, green: 0.491, blue: 0.268))
                //                    .fill(Color.textBackground) // Replace with your desired color
                //                    .frame(width: 120, height: 20) /
                
                Image("HappyCat")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 300, height:400)
                
                
                // Add the "HappyCat" image below "catProfile" and slightly to the right
                             
                                 //  .offset(x: 90) // Slightly move the image to the right
                                 //  .padding(.top, 10) // Adjust vertical spacing as needed
                
               
            }
            .padding(EdgeInsets(top: 0, leading: 0, bottom: 200, trailing: 0))
            
            HStack{
                
              
                
                //  .padding(EdgeInsets(top: -250, leading: 0, bottom: 0, trailing: 0))
                // .offset(y: -60)
                VStack(alignment: .leading, spacing: 10){
                    
                    
                    
                    
                    Text("Name")
                        .background(Color.textBackground)
                        .foregroundColor(Color.lightGrayFont)
                        .cornerRadius(10)
                    
                   
                    //------------------------------------------
                    Text("Age").background(Color.textBackground)
                        .cornerRadius(10)
                    //.offset(x:-45,y:340)
                    
                        .foregroundColor(Color.lightGrayFont)
                    
                    //------------------------------------------
                    Text("Gender").background(Color.textBackground)
                        .cornerRadius(10)
                    // .offset(x:-45,y:350)
                        .foregroundColor(Color.lightGrayFont)
                    
                    //------------------------------------------
                    Text("Breed").background(Color.textBackground)
                        .cornerRadius(10)
                    // .offset(x:-45,y:360)
                        .foregroundColor(Color.lightGrayFont)
                    
                    //------------------------------------------
                    Text("Weight").background(Color.textBackground)
                        .cornerRadius(10)
                    // .offset(x:-45,y:370)
                        .foregroundColor(Color.lightGrayFont)
                    
                    
                    
                    
                }
             //   .padding(EdgeInsets(top: 460, leading: -140, bottom: 0, trailing: 0))
                
//                VStack {
//                            Text("Edit")
//                                .padding()
//                                .background(Rectangle()
//                                    .fill(Color.textBackground)
//                                    .shadow(radius: 0))
//                                .foregroundColor(.lightGrayFont)
//                                                   .padding()
//                        }
                
                //@State private var name: String = ""
//                Image("HappyCat")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: 150, height: 150) // Adjust the size as needed
                 //   .padding(EdgeInsets(top: -10, leading: 220, bottom: 0, trailing: 0))
                
                
                VStack(alignment: .leading, spacing: 10) {
                                 //  TextField("Enter name", text: $name)
                    Text("\(petName)")
                                      // .padding()
                                       .background(Color.textBackground)
                                       .cornerRadius(10)
                                       .frame(width: 150)
                                   
                    Text("\(age)")
                                     //  .padding()
                                       .background(Color.textBackground)
                                       .cornerRadius(10)
                                       .frame(width: 150)
                                   
                    Text("\(gender)")
                                      // .padding()
                                       .background(Color.textBackground)
                                       .cornerRadius(10)
                                       .frame(width: 150)
                                   
                    Text("\(breed)")
                                       //.padding()
                                       .background(Color.textBackground)
                                       .cornerRadius(10)
                                       .frame(width: 150)
                                   
                    Text("\(weight)")
                                       //.padding()
                                       .background(Color.textBackground)
                                       .cornerRadius(10)
                                       .frame(width: 150)
                               }
            }

            .padding(EdgeInsets(top: 460, leading: 1, bottom: 0, trailing: 0))
                        
                        
                    }
        
        
                    
                    
                    
                    
                    
                    
                    
                    
                }
                
                
                
                
             //   Spacer()
                
                
            }
        //.padding(.top, 50)
     
        
        
       


//#Preview {
//    ProfileView()
//}
