//
//  HomePageApp.swift
//  HomePage
//
//  Created by Sara Altamimi on 01/02/1446 AH.
//

import SwiftUI

@main
struct HomePageApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            GetStartedView()
          //  TabBars()
           // GetStartedView()
        }
    }
}
