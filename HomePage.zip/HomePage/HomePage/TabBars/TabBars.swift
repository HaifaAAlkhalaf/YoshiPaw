//
//  TabBars.swift
//  HomePage
//
//  Created by Sara Altamimi on 01/02/1446 AH.
//

import SwiftUI


//enum Tabs : Int {
//    case Tasks = 0
//    case Calendar = 2
//    case Home = 1
//    case Profile = 3
//    
//}

struct TabBars: View {
   // @Binding var selectedTabs: Tabs
    var body: some View {
      
                    Image(systemName:"list.bullet.rectangle.portrait.fill")
                    Text("Tasks")
          
            
            
            
//            ZStack {
//                // Background Image
//                Image("Background")
//                    .resizable()
//                    .scaledToFill()
//                    .edgesIgnoringSafeArea(.all)
//                
//                HStack(spacing: 50) {
//                    Button {
//                        selectedTabs = .Tasks
//                    } label: {
//                        VStack(alignment: .center, spacing: 4) {
//                            Image(systemName:"list.bullet.rectangle.portrait.fill")
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 32, height:32)
//                                .foregroundColor(Color("BrownColor"))
//                            Text("Tasks")
//                                .bold()
//                                .foregroundColor(Color("BrownColor"))
//                        }
//                    }
//                    
//                    Button {
//                        selectedTabs = .Calendar
//                    } label: {
//                        VStack(alignment: .center, spacing: 4) {
//                            Image(systemName:"calendar")
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 32, height:32)
//                                .foregroundColor(Color("BrownColor"))
//                            Text("Calendar")
//                                .bold()
//                                .foregroundColor(Color("BrownColor"))
//                        }
//                    }
//                    
//                    Button {
//                        selectedTabs = .Home
//                    } label: {
//                        VStack(alignment: .center, spacing: 4) {
//                            Image(systemName:"heart.fill")
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 32, height:32)
//                                .foregroundColor(Color("GreenColor"))
//                            Text("Home")
//                                .bold()
//                                .foregroundColor(Color("GreenColor"))
//                        }
//                    }
//                    
//                    Button {
//                        selectedTabs = .Profile
//                    } label: {
//                        VStack(alignment: .center, spacing: 4) {
//                            Image(systemName:"pawprint.fill")
//                                .resizable()
//                                .scaledToFit()
//                                .frame(width: 32, height:32)
//                                .foregroundColor(Color("BrownColor"))
//                            Text("Profile")
//                                .bold()
//                                .foregroundColor(Color("BrownColor"))
//                        }
//                    }
//                }
//                .frame(height: 82)
//            }
        
    }
}

#Preview {
    TabBars()
   // TabBars(selectedTabs: .constant(.Home))
}
