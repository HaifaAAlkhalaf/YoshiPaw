//
//  ContentView.swift
//  HomePage
//
//  Created by Sara Altamimi on 01/02/1446 AH.


import SwiftUI

struct ContentView: View {
    @Binding var petName: String 
    @Binding var age: Int
    @Binding var gender: String
    @Binding var breed: String
    @Binding var weight: Int
    
    var body: some View {
        TabView {
            
            Homee(petName: $petName)
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text("Home")
                }
            
            TasksView()
                .tabItem {
                    Image(systemName: "list.bullet.rectangle.portrait.fill")
                    Text("Tasks")
                        .foregroundColor(Color("BrownColor"))
                }
            
            CalendarView()
                .tabItem {
                    Image(systemName: "calendar")
                    Text("Calendar")
                }
            
        
            
            ProfileView(petName: $petName, age: $age, gender: $gender, breed: $breed, weight: $weight )
                .tabItem {
                    Image(systemName: "pawprint.fill")
                    Text("Profile")
                }
        }
        .accentColor(Color("GreenColor")) // Sets the color of the selected tab icon
    }
}



//#Preview {
//    ContentView()
//}
